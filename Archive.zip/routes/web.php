<?php


use App\Livewire\Admin\Size;
use App\Livewire\Pages\Cart;
use App\Livewire\Pages\Home;
use App\Livewire\Admin\Carts;
use App\Livewire\Admin\Users;
use App\Livewire\Pages\About;
use App\Livewire\Admin\Orders;
use App\Livewire\Admin\Prices;
use App\Livewire\Admin\Address;
use App\Livewire\Admin\Reviews;
use App\Livewire\Pages\Contact;
use App\Livewire\Admin\Category;
use App\Livewire\Admin\Payments;
use App\Livewire\Admin\Products;
use App\Livewire\Pages\Checkout;
use App\Livewire\Pages\Wishlist;
use App\Models\GuestTransaction;
use App\Livewire\Admin\Dashboard;
use App\Livewire\Admin\Favourites;
use App\Livewire\Admin\GuestOrder;
use App\Livewire\Admin\AddProducts;
use App\Livewire\Admin\EditAccount;
use App\Livewire\Admin\EditProduct;
use App\Livewire\Admin\TeamMembers;
use App\Livewire\Admin\ProductItems;
use App\Livewire\Admin\Transactions;
use Illuminate\Support\Facades\Auth;
use App\Livewire\Pages\GuestCheckout;
use Illuminate\Support\Facades\Route;
use App\Livewire\Pages\ProductDetails;
use App\Livewire\Components\ProductItem;
use App\Http\Controllers\ReceiptController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\LogoutController;
use App\Http\Controllers\Auth\RegisterController;
use App\Livewire\Pages\Products as PagesProducts;
use App\Http\Controllers\Payment\PaypalController;
use App\Http\Controllers\Payment\StripeController;
use App\Http\Controllers\payment\GuestPaypalController;
use App\Http\Controllers\payment\GuestStripeController;
use App\Livewire\Profile\Dashboard as ProfileDashboard;
use App\Livewire\Admin\GuestTransaction as AdminGuestTransaction;
use App\Http\Controllers\Admin\LoginController as AdminLoginController;
use App\Http\Controllers\Admin\LogoutController as AdminLogoutController;
use App\Livewire\Admin\GuestPayment;
use App\Livewire\Components\Order;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get("/reset-password", function () {
    return view("auth.passwords.email");
})->name("reset-password");


Auth::routes(['verify' => true]);




//Auth Routes
Route::get("login", [LoginController::class, "index"])->name("login");
Route::post("login", [LoginController::class, "login"]);

// Route::post("logout", [LoginController::class, "logout"]);

Route::get("register", [RegisterController::class, "index"])->name("register");
Route::post("register", [RegisterController::class, "store"]);

Route::get("admin/login", [AdminLoginController::class, "index"])->name("admin-login");
Route::post("admin/login", [AdminLoginController::class, "login"]);

Route::get("about", About::class)->name("about");

Route::get("contact-us", Contact::class)->name("contact");

Route::middleware('web')->group(function () {
    Route::post("logout", [LogoutController::class, "logout"])->name("logout");

    Route::get('/generate-pdf/{id}', [ReceiptController::class, 'index'])->name('generate.pdf');
});

//Pages Routes
Route::get("/", Home::class);

Route::get("/home", Home::class)->name("home");

Route::get("shop", PagesProducts::class)->name("products");

Route::get("shop/{id}", ProductDetails::class)->name("product-detail");

Route::get("cart", Cart::class)->name("cart");

Route::get("guest-checkout", GuestCheckout::class)->name("guess-checkout");


Route::group(["middleware" => ["auth", "verified"]], function () {
    // Route::group(["middleware" => "auth"], function () {

    Route::get("wishlist", Wishlist::class)->name("wishlist");

    Route::get("checkout", Checkout::class)->name("checkout");

    Route::get("order/{id}", Order::class)->name("order");

    //Profile
    Route::get("account", ProfileDashboard::class)->name("dashboard");


    // payment
    Route::post('/pay', [StripeController::class, 'checkout'])->name('pay');
    Route::get('/pay/success', [StripeController::class, 'success'])->name('checkout.success');
    Route::get('/pay/cancel', [StripeController::class, 'cancel'])->name('checkout.cancel');


    Route::post('/payWithPaypal', [PaypalController::class, 'checkout'])->name('payWithPaypal');
    Route::get('/payWithPaypal/success', [PaypalController::class, 'success'])->name('checkout.paypal.success');
    Route::get('/payWithPaypal/cancel', [PaypalController::class, 'cancel'])->name('checkout.paypal.cancel');
});



Route::post('/guest-pay', [GuestStripeController::class, 'checkout'])->name('guest-pay');
Route::get('/guest-pay/success', [GuestStripeController::class, 'success'])->name('guest-checkout.success');
Route::get('guest-pay/cancel', [GuestStripeController::class, 'cancel'])->name('guest-checkout.cancel');


Route::post('/guest-payWithPaypal', [GuestPaypalController::class, 'checkout'])->name('guest-payWithPaypal');
Route::get('/guest-payWithPaypal/success', [GuestPaypalController::class, 'success'])->name('guest-checkout.paypal.success');
Route::get('/guest-payWithPaypal/cancel', [GuestPaypalController::class, 'cancel'])->name('guest-checkout.paypal.cancel');




//admin routes

Route::group(["middleware" => ["auth", "is_admin"]], function () {

    Route::get("admin/dashboard", Dashboard::class)->name("admin-dashboard");

    Route::get("admin/products", Products::class)->name("admin-product");

    Route::get("admin/add-product", AddProducts::class)->name("add-product");

    Route::get("admin/products/{id}", EditProduct::class)->name("edit-product");

    Route::get("admin/products/{id}/items", ProductItems::class)->name("product-item");

    Route::get("admin/categories", Category::class)->name("admin-categories");

    Route::get("admin/sizes", Size::class)->name("admin-size");

    Route::get("admin/carts", Carts::class)->name("admin-cart");

    Route::get("admin/wishlists", Favourites::class)->name("admin-wishlist");

    Route::get("admin/reviews", Reviews::class)->name("admin-review");

    Route::get("admin/orders/{id}", Orders::class)->name("admin-order");

    Route::get("admin/team-members", TeamMembers::class)->name("team-member");

    Route::get("admin/users", Users::class)->name("users");

    Route::get("admin/address", Address::class)->name("admin-address");

    Route::get("admin/account", EditAccount::class)->name("edit-account");

    Route::get("admin/transactions", Transactions::class)->name("admin-transaction");

    Route::get("admin/payments", Payments::class)->name("admin-payment");

    Route::get("admin/prices", Prices::class)->name("admin-price");

    Route::post("admin/logout", [AdminLogoutController::class, "logout"])->name("admin-logout");


    //Guest Transaction
    Route::get("admin/guest-orders/{id}", GuestOrder::class)->name("admin-guest-order");

    Route::get("admin/guest-transactions", AdminGuestTransaction::class)->name("guest-transaction");

    Route::get("admin/guest-payments", GuestPayment::class)->name("admin-guest-payment");
});


//Payment controller
// Route::get('/pay', [StripeController::class, 'index'])->name('pay');
// Route::post('pay-checkout', [StripeController::class, 'checkout']);

